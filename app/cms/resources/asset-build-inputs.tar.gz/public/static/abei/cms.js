(() => {
 'use strict';
 function ready() {
  const menu=document.querySelector('.menu-toggle');
  if(menu)menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));document.querySelector('.nav-links').classList.toggle('open',open);menu.querySelector('.menu-icon').textContent=open?'×':'☰';});
  document.querySelectorAll('.nav-links a.active,.side-nav a.active').forEach(a=>a.setAttribute('aria-current','page'));
  const hero=document.querySelector('.hero');
  if(hero){
   const slides=[...hero.querySelectorAll('.cms-slide')];
   const dotWrap=hero.querySelector('.carousel-dots');let index=0,timer;
   const reduced=matchMedia('(prefers-reduced-motion: reduce)');
   slides.forEach((slide,i)=>{const button=document.createElement('button');button.type='button';button.setAttribute('aria-label',`切换至第 ${i+1} 张`);button.addEventListener('click',()=>{show(i);start();});dotWrap.append(button);});
   const dots=[...dotWrap.children];
   function show(next){if(!slides.length)return;index=(next+slides.length)%slides.length;slides.forEach((slide,i)=>{slide.classList.toggle('is-current',i===index);slide.classList.toggle('is-hidden',i!==index);slide.setAttribute('aria-hidden',String(i!==index));slide.tabIndex=i===index?0:-1;dots[i].classList.toggle('active',i===index);dots[i].setAttribute('aria-pressed',String(i===index));});}
   const stop=()=>clearInterval(timer);
   const start=()=>{stop();if(slides.length>1&&!reduced.matches&&!hero.matches(':hover')&&!hero.contains(document.activeElement)&&!document.hidden)timer=setInterval(()=>show(index+1),6500);};
   hero.querySelector('.carousel-prev').addEventListener('click',()=>{show(index-1);start();});
   hero.querySelector('.carousel-next').addEventListener('click',()=>{show(index+1);start();});
   hero.addEventListener('mouseenter',stop);hero.addEventListener('mouseleave',start);hero.addEventListener('focusin',stop);hero.addEventListener('focusout',()=>setTimeout(start,0));
   hero.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();show(index+(event.key==='ArrowLeft'?-1:1));}});
   document.addEventListener('visibilitychange',start);reduced.addEventListener('change',start);show(0);start();
  }
  const toc=document.querySelector('#article-toc');
  if(toc){document.querySelectorAll('.article-body h2').forEach((heading,i)=>{if(!heading.id)heading.id='section-'+(i+1);const li=document.createElement('li'),a=document.createElement('a');a.href='#'+encodeURIComponent(heading.id);a.textContent=heading.textContent.replace(/^\d+\s*\/\s*/,'');li.append(a);toc.append(li);});if(toc.children.length)document.querySelector('.toc-box').hidden=false;}
  const params=new URLSearchParams(location.search),query=params.get('keywords')||'';
  if(query){document.querySelectorAll('.header-search input[name="keywords"]').forEach(input=>input.value=query);}
  const total=document.querySelector('#search-total'),server=document.querySelector('#server-total');if(total&&server)total.textContent=server.textContent.trim();
  const filters=[...document.querySelectorAll('[data-search-type]')];if(filters.length){const type=params.get('typeid')||filters[0].dataset.searchType;filters.forEach(a=>{const selected=a.dataset.searchType===type;a.classList.toggle('active',selected);if(selected)a.setAttribute('aria-current','true');});}
  if(query&&document.querySelector('#search-total')){
   document.querySelectorAll('#article-results h2 a,#article-results p').forEach(element=>{
    const text=element.textContent,needle=query.toLocaleLowerCase(),lower=text.toLocaleLowerCase();let position=0,found;const fragment=document.createDocumentFragment();
    while((found=lower.indexOf(needle,position))!==-1){fragment.append(document.createTextNode(text.slice(position,found)));const mark=document.createElement('mark');mark.className='search-highlight';mark.textContent=text.slice(found,found+query.length);fragment.append(mark);position=found+query.length;}
    fragment.append(document.createTextNode(text.slice(position)));element.replaceChildren(fragment);
   });
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();

﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','da',{placeholder:{title:'Egenskaber for pladsholder',toolbar:'Opret pladsholder',text:'Tekst til pladsholder',edit:'Redigér pladsholder',textMissing:'Pladsholder skal indeholde tekst'}});
